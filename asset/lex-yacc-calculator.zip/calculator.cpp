#include "calculator.hpp"

#include <cmath>
#include <memory>
#include <stdexcept>
#include <string>
#include <type_traits>
#include <utility>
#include <vector>

NodeExp::NodeExp(OperationType opt, const String &text) : opt_(opt), text_(text) {
    if (not this->IsElementType())
        throw std::runtime_error("NodeExp(OperationType, const String &) cannot construct non-element type.");
    this->LoadInfo();
}
NodeExp::NodeExp(OperationType opt, std::initializer_list<NodeExp *> args) : opt_(opt), args_(args) {
    if (this->IsElementType())
        throw std::runtime_error("NodeExp(OperationType, std::initializer_list<NodeExp *>) cannot construct element type.");
    this->LoadInfo();
}

void NodeExp::Draw() const {
    int now_node_cnt = draw_node_cnt_++;
    printf("        %d [label=\"%s\"]\n", now_node_cnt, this->text_.c_str());
    for (const NodeExp *arg : this->args_) {
        printf("        %d -- %d [style=solid]\n", now_node_cnt, draw_node_cnt_);
        arg->Draw();
    }
}

NodeExp::~NodeExp() noexcept {
    for (NodeExp *arg : this->args_)
        delete arg;
}

void NodeExp::LoadInfo() {
    switch (this->opt_) {
        case OperationType::Add:
            if (this->args_.size() == 1) {
                this->value_ = +this->args_.at(0)->value_;
                this->text_ = String("(+): %.15lg").format(this->value_);
            } else {
                this->value_ = this->args_.at(0)->value_ + this->args_.at(1)->value_;
                this->text_ = String("+: %.15lg").format(this->value_);
            }
            return;
        case OperationType::Sub:
            if (this->args_.size() == 1) {
                this->value_ = -this->args_.at(0)->value_;
                this->text_ = String("(-): %.15lg").format(this->value_);
            } else {
                this->value_ = this->args_.at(0)->value_ - this->args_.at(1)->value_;
                this->text_ = String("-: %.15lg").format(this->value_);
            }
            return;
        case OperationType::Mul:
            this->value_ = this->args_.at(0)->value_* this->args_.at(1)->value_;
            this->text_ = String("*: %.15lg").format(this->value_);
            return;
        case OperationType::Div:
            this->value_ = this->args_.at(0)->value_ / this->args_.at(1)->value_;
            this->text_ = String("/: %.15lg").format(this->value_);
            return;
        case OperationType::Power:
            this->value_ = std::pow(this->args_.at(0)->value_, this->args_.at(1)->value_);
            this->text_ = String("**: %.15lg").format(this->value_);
            return;
        case OperationType::Brackets:
            this->value_ = this->args_.at(0)->value_;
            this->text_ = String("(...): %.15lg").format(this->value_);
            return;
        case OperationType::Floating:
            this->value_ = std::stod(this->text_);
            this->text_ = String("Floating(%s): %.15lg").format(this->text_.c_str(), this->value_);
            return;
        case OperationType::Decimal:
            this->value_ = std::stod(this->text_);
            this->text_ = String("Decimal(%s): %.0lf").format(this->text_.c_str(), this->value_);
            return;
        case OperationType::Binary:
            this->value_ = Bin2Decimal(this->text_);
            this->text_ = String("Binary(%s): %.0lf").format(this->text_.c_str(), this->value_);
            return;
        case OperationType::Octal:
            this->value_ = Oct2Decimal(this->text_);
            this->text_ = String("Octal(%s): %.0lf").format(this->text_.c_str(), this->value_);
            return;
        case OperationType::Hexadecimal:
            this->value_ = Hex2Decimal(this->text_);
            this->text_ = String("Hexadecimal(%s): %.0lf").format(this->text_.c_str(), this->value_);
            return;
        case OperationType::PI:
            this->value_ = M_PI;
            this->text_ = String("PI: %.5lf").format(this->value_);
            return;
        case OperationType::E:
            this->value_ = M_E;
            this->text_ = String("E: %.5lf").format(this->value_);
            return;
        case OperationType::Sin:
            this->value_ = std::sin(this->args_.at(0)->value_);
            this->text_ = String("sin(...): %.15lg").format(this->value_);
            return;
        case OperationType::Cos:
            this->value_ = std::cos(this->args_.at(0)->value_);
            this->text_ = String("cos(...): %.15lg").format(this->value_);
            return;
        case OperationType::Tan:
            this->value_ = std::tan(this->args_.at(0)->value_);
            this->text_ = String("tan(...): %.15lg").format(this->value_);
            return;
        case OperationType::Asin:
            this->value_ = std::asin(this->args_.at(0)->value_);
            this->text_ = String("asin(...): %.15lg").format(this->value_);
            return;
        case OperationType::Acos:
            this->value_ = std::acos(this->args_.at(0)->value_);
            this->text_ = String("acos(...): %.15lg").format(this->value_);
            return;
        case OperationType::Atan:
            this->value_ = std::atan(this->args_.at(0)->value_);
            this->text_ = String("atan(...): %.15lg").format(this->value_);
            return;
        case OperationType::Log:
            this->value_ = std::log10(this->args_.at(0)->value_);
            this->text_ = String("log10(...): %.15lg").format(this->value_);
            return;
        case OperationType::Ln:
            this->value_ = std::log(this->args_.at(0)->value_);
            this->text_ = String("ln(...): %.15lg").format(this->value_);
            return;
        default:
            throw std::runtime_error("Unknown Operation Type");
    }
}

bool NodeExp::IsElementType() const {
    switch (this->opt_) {
        case OperationType::Add:
        case OperationType::Sub:
        case OperationType::Mul:
        case OperationType::Div:
        case OperationType::Power:
        case OperationType::Brackets:
        case OperationType::Sin:
        case OperationType::Cos:
        case OperationType::Tan:
        case OperationType::Asin:
        case OperationType::Acos:
        case OperationType::Atan:
        case OperationType::Log:
        case OperationType::Ln:
            return false;
        case OperationType::Floating:
        case OperationType::Decimal:
        case OperationType::Binary:
        case OperationType::Octal:
        case OperationType::Hexadecimal:
        case OperationType::PI:
        case OperationType::E:
            return true;
        default:
            throw std::runtime_error("Unknown Operation Type");
    }
}

double NodeExp::Bin2Decimal(const String &bin) {
    double x = 0;
    for (int i = 2; i < bin.size(); ++i)
        x = x * 2 + (bin.at(i) - '0');
    return x;
}
double NodeExp::Oct2Decimal(const String &oct) {
    double x = 0;
    for (int i = 2; i < oct.size(); ++i)
        x = x * 8 + (oct.at(i) - '0');
    return x;
}
double NodeExp::Hex2Decimal(const String &hex) {
    static auto get = [](char c) -> int {
        if ('0' <= c and c <= '9')
            return c - '0';
        if ('A' <= c and c <= 'Z')
            return c - 'A' + 10;
        return c - 'a' + 10;
    };
    double x = 0;
    for (int i = 2; i < hex.size(); ++i)
        x = x * 16 + get(hex.at(i));
    return x;
}

int draw_root_cnt = 0;

void draw(const NodeExp *root) {
    printf(
        "    \n"
        "    subgraph cluster_%d {\n"
        "        label=\"Parser Tree %d\"\n"
        "        \n",
        draw_root_cnt, draw_root_cnt + 1);

    root->Draw();

    printf("    }\n");

    ++draw_root_cnt;
}

void draw_error() {
    printf(
        "    \n"
        "    subgraph cluster_%d {\n"
        "        label=\"Parser Tree %d\"\n"
        "        err%d [label=\"SyntaxError\"]\n"
        "    }\n",
        draw_root_cnt, draw_root_cnt + 1, draw_root_cnt);

    ++draw_root_cnt;
}
