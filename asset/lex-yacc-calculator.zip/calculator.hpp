#pragma once
#include <string>
#include <variant>
#include <vector>

template <std::size_t BUFSIZE>
class BasicString : public std::string {
   public:
    using std::string::basic_string;

    template <typename... Args>
    BasicString<BUFSIZE> format(Args &&...args) {
        sprintf(buf, this->c_str(), std::forward<Args>(args)...);
        return buf;
    };

   private:
    inline static char buf[BUFSIZE];
};
using String = BasicString<1024>;

enum class OperationType : uint8_t {
    Add,
    Sub,
    Mul,
    Div,
    Power,
    Brackets,
    Floating,
    Decimal,
    Binary,
    Octal,
    Hexadecimal,
    PI,
    E,
    Sin,
    Cos,
    Tan,
    Asin,
    Acos,
    Atan,
    Log,
    Ln,
};

class NodeExp {
   public:
    NodeExp(OperationType opt, const String &text = "");
    NodeExp(OperationType opt, std::initializer_list<NodeExp *> args);

    void Draw() const;

    ~NodeExp() noexcept;

   private:
    OperationType opt_;
    double value_;
    String text_;
    std::vector<NodeExp *> args_;

    inline static int draw_node_cnt_ = 0;

    void LoadInfo();

    bool IsElementType() const;

    static double Bin2Decimal(const String &bin);
    static double Oct2Decimal(const String &oct);
    static double Hex2Decimal(const String &hex);
};

void draw(const NodeExp *root);
void draw_error();
