#!/usr/bin/sh

which g++ || sudo apt install build-essential
which flex || sudo apt install flex
which bison || sudo apt install bison
which dot || sudo apt install graphviz
