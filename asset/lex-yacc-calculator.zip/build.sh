#!/usr/bin/sh

flex -t book.l > lex.yy.cpp
bison --output book.tab.cpp -dvt book.y
g++ book.tab.cpp lex.yy.cpp calculator.cpp -o main
