#!/usr/bin/sh

rm book.gv book.gv.png book.gv.svg
rm book.output book.tab.cpp book.tab.hpp
rm lex.yy.cpp
rm main
