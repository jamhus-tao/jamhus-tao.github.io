#!/usr/bin/sh

./main > book.gv
dot -T svg -T png -O book.gv
